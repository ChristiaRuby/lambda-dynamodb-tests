from moto import mock_dynamodb
import pytest
from lambda_app.lambda_function import lambda_handler, table
import boto3
import os
from botocore.exceptions import ClientError
import datetime
@pytest.fixture
def aws_credentials():
   """Mocked AWS Credentials for moto."""
   os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
   os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
   os.environ['AWS_SESSION_TOKEN'] = 'testing'
   os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
   os.environ['DYNAMODB_TABLE'] = 'Users'
@pytest.fixture
def dynamodb_mock(aws_credentials):
   with mock_dynamodb():
       dynamodb = boto3.resource('dynamodb')
       test_table = dynamodb.create_table(
           TableName='Users',
           KeySchema=[{'AttributeName': 'email', 'KeyType': 'HASH'}],
           AttributeDefinitions=[{'AttributeName': 'email', 'AttributeType': 'S'}],
           ProvisionedThroughput={'ReadCapacityUnits': 1, 'WriteCapacityUnits': 1}
       )
       test_table.meta.client.get_waiter('table_exists').wait(TableName='Users')
       yield test_table
def test_lambda_handler_success(dynamodb_mock):
   """Test successful execution of lambda handler"""
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski',
       'email': 'jan.kowalski@example.com'
   }
   response = lambda_handler(event, {}, table_override=dynamodb_mock)
   assert response['statusCode'] == 200
   assert 'User added successfully' in response['body']
   item = dynamodb_mock.get_item(Key={'email': 'jan.kowalski@example.com'})
   assert 'Item' in item
   assert item['Item']['first_name'] == 'Jan'
   assert item['Item']['last_name'] == 'Kowalski'
def test_lambda_handler_missing_email():
   """Test missing email field"""
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski'
   }
   response = lambda_handler(event, {})
   assert response['statusCode'] == 400
   assert 'Missing or empty field: email' in response['body']
def test_lambda_handler_missing_first_name():
   """Test missing first_name field"""
   event = {
       'last_name': 'Kowalski',
       'email': 'jan.kowalski@example.com'
   }
   response = lambda_handler(event, {})
   assert response['statusCode'] == 400
   assert 'Missing or empty field: first_name' in response['body']
def test_lambda_handler_missing_last_name():
   """Test missing last_name field"""
   event = {
       'first_name': 'Jan',
       'email': 'jan.kowalski@example.com'
   }
   response = lambda_handler(event, {})
   assert response['statusCode'] == 400
   assert 'Missing or empty field: last_name' in response['body']
def test_lambda_handler_empty_fields():
   """Test empty required fields"""
   for field in ['first_name', 'last_name', 'email']:
       event = {
           'first_name': 'Jan',
           'last_name': 'Kowalski',
           'email': 'jan.kowalski@example.com'
       }
       event[field] = ''
       response = lambda_handler(event, {})
       assert response['statusCode'] == 400
       assert f'Missing or empty field: {field}' in response['body']
def test_lambda_handler_invalid_email():
   """Test invalid email format"""
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski',
       'email': 'invalid-email'
   }
   response = lambda_handler(event, {})
   assert response['statusCode'] == 400
   assert 'Invalid email format' in response['body']
def test_lambda_handler_duplicate_email(dynamodb_mock):
   """Test duplicate email handling"""
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski',
       'email': 'jan.kowalski@example.com'
   }
   lambda_handler(event, {}, table_override=dynamodb_mock)
   response = lambda_handler(event, {}, table_override=dynamodb_mock)
   assert response['statusCode'] == 409
   assert 'already exists' in response['body']
def test_lambda_handler_dynamodb_error_on_check(monkeypatch, dynamodb_mock):
   """Test DynamoDB error during existence check"""
   def mock_get_item(*args, **kwargs):
       raise ClientError({'Error': {'Code': '500', 'Message': 'Mocked Error'}}, 'get_item')
   monkeypatch.setattr(dynamodb_mock, 'get_item', mock_get_item)
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski',
       'email': 'jan.kowalski@example.com'
   }
   response = lambda_handler(event, {}, table_override=dynamodb_mock)
   assert response['statusCode'] == 500
   assert 'Error checking for existing user' in response['body']
def test_lambda_handler_dynamodb_error_on_create(monkeypatch, dynamodb_mock):
   """Test DynamoDB error during user creation"""
   def mock_get_item(*args, **kwargs):
       return {}
   def mock_put_item(*args, **kwargs):
       raise ClientError({'Error': {'Code': '500', 'Message': 'Mocked Error'}}, 'put_item')
   monkeypatch.setattr(dynamodb_mock, 'get_item', mock_get_item)
   monkeypatch.setattr(dynamodb_mock, 'put_item', mock_put_item)
   event = {
       'first_name': 'Jan',
       'last_name': 'Kowalski',
       'email': 'jan.kowalski@example.com'
   }
   response = lambda_handler(event, {}, table_override=dynamodb_mock)
   assert response['statusCode'] == 500
   assert 'Error creating user' in response['body']