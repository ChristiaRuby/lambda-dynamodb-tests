import os
import json
import boto3
from botocore.exceptions import ClientError
import re
import datetime
# Initialize table at module level
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('Users')
def validate_email(email):
   """Basic email validation"""
   pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
   return re.match(pattern, email) is not None
def lambda_handler(event, context, table_override=None):
   # Use override table if provided (for testing), otherwise use the module-level table
   current_table = table_override if table_override is not None else table
   try:
       # Validate required fields
       required_fields = ["first_name", "last_name", "email"]
       for field in required_fields:
           if field not in event or not event[field].strip():
               return {
                   "statusCode": 400,
                   "body": f"Missing or empty field: {field}"
               }
       # Validate email format
       if not validate_email(event['email']):
           return {
               "statusCode": 400,
               "body": "Invalid email format"
           }
       # Validate field lengths
       if len(event['first_name']) > 50 or len(event['last_name']) > 50:
           return {
               "statusCode": 400,
               "body": "First name and last name must be less than 50 characters"
           }
       # Check if user exists
       try:
           existing_user = current_table.get_item(Key={'email': event['email']})
           if 'Item' in existing_user:
               return {
                   "statusCode": 409,
                   "body": f"User with email {event['email']} already exists"
               }
       except ClientError as e:
           return {
               "statusCode": 500,
               "body": f"Error checking for existing user: {str(e)}"
           }
       # Add creation timestamp
       event['created_at'] = datetime.datetime.now().isoformat()
       # Create user
       try:
           current_table.put_item(Item=event)
           return {
               "statusCode": 200,
               "body": "User added successfully"
           }
       except ClientError as e:
           return {
               "statusCode": 500,
               "body": f"Error creating user: {str(e)}"
           }
   except Exception as e:
       return {
           "statusCode": 500,
           "body": f"Unexpected error: {str(e)}"
       }