# AWS Lambda + DynamoDB + Pytest

This project contains a Lambda function that stores user data in DynamoDB and is tested using `pytest` and `moto`.

## Requirements

- Python 3.8+
- boto3
- pytest
- moto

## Run Tests Locally

```bash
pip install -r requirements.txt
pytest tests/
